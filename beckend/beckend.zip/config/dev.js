module.exports = {
  'dbURL': 'mongodb+srv://angel:liamliaerick123@cluster0.3mhf7.mongodb.net/GOBNB_DB?retryWrites=true&w=majority',
}
